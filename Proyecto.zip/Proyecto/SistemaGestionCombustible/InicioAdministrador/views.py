from django.core.files.base import ContentFile
from django.shortcuts import render
from django.views.generic import ListView, DeleteView, CreateView
from .models import Combustible, Departamento, Estacion, Municipio, Registro, Servicio
from django.urls import reverse_lazy
from .forms import EstacionForms, MunicipioForms, RegistroForms
# Create your views here.

class inicioAdministrador(ListView):
    model = Registro
    template_name = 'InicioAdmin.html'

    form_class=RegistroForms
    second_form_class=EstacionForms
    third_form_class=MunicipioForms

    #get_context_data: sirve para pasar información al template diferente al model o al queryset
    def get_context_data(self, **kwargs):
        context = super(inicioAdministrador,self).get_context_data(**kwargs)
        if 'registro' not in context:
            context['registro'] = self.form_class(self.request.GET)
        if 'estacion' not in context:
            context['estacion'] = self.second_form_class(self.request.GET)
        if 'municipio' not in context:
            context['municipio'] = self.third_form_class(self.request.GET)
        return context       

class eliminarCombustible(DeleteView):
    model = Registro
    template_name = 'eliminar.html'
    success_url = reverse_lazy('inicioAdministrador')

