from django.shortcuts import render

# Create your views here.
def calcular(request):
    return render(request,"calcular.html")