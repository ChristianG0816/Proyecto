from .models import Combustible, Departamento, Estacion, Municipio, Registro, Servicio
from django.shortcuts import render
from django.http import request, HttpRequest
from django.views.generic import ListView

# Create your views here.
#def InicioUsuario(request):

 #       estaciones = Estacion.objects.all()
 #       departamentos = Departamento.objects.all()
 #       municipios = Municipio.objects.all()
 #       registros = Registro.objects.all()
 #       servicios = Servicio.objects.all()
    
 #       contexto = {
 #           'estaciones': estaciones,
 #           'departamentos': departamentos,
 #           'municipios': municipios,
 #           'registros': registros,
 #           'servicios': servicios,
 #       }
 #       return render(request,'index.html',contexto)

#Clase para importar todos los datos de la base de datos

class inicioUsuario(ListView):
    model = Registro
    template_name = 'index.html'


   
