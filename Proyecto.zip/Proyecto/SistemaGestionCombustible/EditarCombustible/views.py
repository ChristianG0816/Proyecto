from django.shortcuts import render
from django.http.response import HttpResponseRedirect
from django.urls import reverse_lazy
from .models import Registro, Estacion
from .forms import EstacionForms, MunicipioForms, RegistroForms
from django.views.generic import UpdateView

class editarCombustible(UpdateView):
    
    model = Registro
    second_model = Estacion

    template_name='editar.html'
    form_class=RegistroForms
    second_form_class=EstacionForms

    success_url = reverse_lazy('inicioAdministrador')

    def get_context_data(self, **kwargs):
        context = super(editarCombustible,self).get_context_data(**kwargs)
        pk = self.kwargs.get('pk',0)

        #Variables que contendra el objeto de registro y estacion

        registro = self.model.objects.get(idregistro=pk)
        estacion = self.second_model.objects.get(nombree = registro.nombree)

        #Ahora vamos a instanciarlos en los formularios

        if 'estacion' not in context:
            context['estacion']=self.form_class(self.request.GET)
        if 'registro' not in context:
            context['registro']=self.second_form_class(instance = estacion)
        
        context['idregistro'] = pk
        return context

    def post(self, request, *args, **kwargs):
        self.object = self.get_object
        id_registro = kwargs['pk']
        registro = self.model.objects.get(idregistro = id_registro)
        estacion = self.second_model.objects.get(nombree = registro.nombree)
        form = self.form_class(request.POST, instance = registro)
        form2 = self.form_class(request.POST, instance = estacion)
        if form.is_valid() and form2.is_valid():
            form.save()
            form2.save()
            return HttpResponseRedirect(self.success_url)
        else:
            return HttpResponseRedirect(self.success_url)