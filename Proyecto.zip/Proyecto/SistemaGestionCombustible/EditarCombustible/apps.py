from django.apps import AppConfig


class EditarcombustibleConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'EditarCombustible'
